---
name: Feature request
about: Suggest an idea for this project
---

**Problem Description**

<!-- Please add a clear and concise description of what the problem is. -->

**Proposed Solution**

<!-- Describe the solution you'd like in a clear and concise manner -->

**Describe alternatives you've considered**

<!-- A clear and concise description of any alternative solutions or features you've considered. -->

**Additional context**

<!-- Add any other context or screenshots about the feature request here. -->
