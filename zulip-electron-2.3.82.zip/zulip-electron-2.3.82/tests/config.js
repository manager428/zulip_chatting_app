const path = require('path')

const TEST_APP_PRODUCT_NAME = 'ZulipTest'

module.exports = {
  TEST_APP_PRODUCT_NAME
}
