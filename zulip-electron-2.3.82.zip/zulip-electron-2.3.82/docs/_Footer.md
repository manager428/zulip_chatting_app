### Want to contribute to this Wiki?

[Edit `/docs` files and send a pull request.](https://github.com/zulip/zulip-electron/tree/master/docs)
